﻿namespace Royal_Roxn.Db
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            dept_button = new Button();
            button4 = new Button();
            button6 = new Button();
            button5 = new Button();
            ddv_dept = new Button();
            dept_timer = new System.Windows.Forms.Timer(components);
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            main_panel = new Panel();
            panel = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            main_panel.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(52, 22);
            label1.Name = "label1";
            label1.Size = new Size(93, 34);
            label1.TabIndex = 1;
            label1.Text = "Menu";
            label1.Click += label1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.dashboard_5486;
            pictureBox1.Location = new Point(3, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(44, 44);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // dept_button
            // 
            dept_button.Anchor = AnchorStyles.None;
            dept_button.BackColor = Color.FromArgb(107, 124, 134);
            dept_button.FlatAppearance.BorderSize = 0;
            dept_button.Font = new Font("Tahoma", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dept_button.ForeColor = Color.White;
            dept_button.ImageAlign = ContentAlignment.MiddleLeft;
            dept_button.Location = new Point(8, 84);
            dept_button.Name = "dept_button";
            dept_button.Size = new Size(193, 90);
            dept_button.TabIndex = 1;
            dept_button.Text = "Departments";
            dept_button.TextAlign = ContentAlignment.MiddleLeft;
            dept_button.UseVisualStyleBackColor = false;
            dept_button.Click += dept_button_Click;
            // 
            // button4
            // 
            button4.Anchor = AnchorStyles.None;
            button4.BackColor = Color.FromArgb(107, 124, 134);
            button4.Font = new Font("Tahoma", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.White;
            button4.ImageAlign = ContentAlignment.MiddleLeft;
            button4.Location = new Point(15, 304);
            button4.Name = "button4";
            button4.Size = new Size(193, 82);
            button4.TabIndex = 2;
            button4.Text = "Realtor's Info";
            button4.TextAlign = ContentAlignment.MiddleLeft;
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button6
            // 
            button6.Anchor = AnchorStyles.None;
            button6.BackColor = Color.FromArgb(107, 124, 134);
            button6.Font = new Font("Tahoma", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.ForeColor = Color.White;
            button6.ImageAlign = ContentAlignment.MiddleLeft;
            button6.Location = new Point(15, 210);
            button6.Name = "button6";
            button6.Size = new Size(186, 61);
            button6.TabIndex = 4;
            button6.Text = "Employee ";
            button6.TextAlign = ContentAlignment.MiddleLeft;
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button5
            // 
            button5.Anchor = AnchorStyles.None;
            button5.BackColor = Color.FromArgb(107, 124, 134);
            button5.FlatAppearance.BorderSize = 0;
            button5.Font = new Font("Tahoma", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.White;
            button5.ImageAlign = ContentAlignment.MiddleLeft;
            button5.Location = new Point(10, 428);
            button5.Name = "button5";
            button5.Size = new Size(211, 83);
            button5.TabIndex = 3;
            button5.Text = "Management info ";
            button5.TextAlign = ContentAlignment.MiddleLeft;
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // ddv_dept
            // 
            ddv_dept.Anchor = AnchorStyles.None;
            ddv_dept.BackColor = Color.FromArgb(107, 124, 134);
            ddv_dept.FlatAppearance.BorderSize = 0;
            ddv_dept.Font = new Font("Tahoma", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ddv_dept.ForeColor = Color.White;
            ddv_dept.ImageAlign = ContentAlignment.MiddleLeft;
            ddv_dept.Location = new Point(17, 540);
            ddv_dept.Name = "ddv_dept";
            ddv_dept.Size = new Size(191, 70);
            ddv_dept.TabIndex = 0;
            ddv_dept.Text = "       About";
            ddv_dept.TextAlign = ContentAlignment.MiddleLeft;
            ddv_dept.UseVisualStyleBackColor = false;
            ddv_dept.Click += button1_Click;
            // 
            // main_panel
            // 
            main_panel.BackColor = SystemColors.AppWorkspace;
            main_panel.Controls.Add(pictureBox1);
            main_panel.Controls.Add(button5);
            main_panel.Controls.Add(ddv_dept);
            main_panel.Controls.Add(dept_button);
            main_panel.Controls.Add(label1);
            main_panel.Controls.Add(button4);
            main_panel.Controls.Add(button6);
            main_panel.Dock = DockStyle.Left;
            main_panel.Location = new Point(0, 0);
            main_panel.Name = "main_panel";
            main_panel.Size = new Size(224, 956);
            main_panel.TabIndex = 5;
            // 
            // panel
            // 
            panel.Location = new Point(230, 0);
            panel.Name = "panel";
            panel.Size = new Size(1693, 953);
            panel.TabIndex = 6;
            panel.Paint += panel_Paint;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(1924, 956);
            Controls.Add(panel);
            Controls.Add(main_panel);
            Name = "Dashboard";
            Text = "Dashboard";
            Load += Dashboard_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            main_panel.ResumeLayout(false);
            main_panel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Button ddv_dept;
        private Panel dept_panel;
        private PictureBox pictureBox1;
        private Label label1;
        private Button dept_button;
        private Button button4;
        private Button button5;
        private Button button6;
        private System.Windows.Forms.Timer dept_timer;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Panel main_panel;
        private Panel panel;
    }
}