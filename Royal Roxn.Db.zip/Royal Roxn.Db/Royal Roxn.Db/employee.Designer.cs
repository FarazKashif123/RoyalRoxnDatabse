﻿namespace Royal_Roxn.Db
{
    partial class employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(employee));
            label1 = new Label();
            panel1 = new Panel();
            DataDialerVoip = new Label();
            employee_grid = new DataGridView();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)employee_grid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(3, 19);
            label1.Name = "label1";
            label1.Size = new Size(152, 34);
            label1.TabIndex = 1;
            label1.Text = "Employee";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(51, 102, 153);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1621, 53);
            panel1.TabIndex = 4;
            // 
            // DataDialerVoip
            // 
            DataDialerVoip.Anchor = AnchorStyles.None;
            DataDialerVoip.AutoSize = true;
            DataDialerVoip.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            DataDialerVoip.Location = new Point(12, 349);
            DataDialerVoip.Name = "DataDialerVoip";
            DataDialerVoip.Size = new Size(1484, 156);
            DataDialerVoip.TabIndex = 2;
            DataDialerVoip.Text = resources.GetString("DataDialerVoip.Text");
            DataDialerVoip.Click += DataDialerVoip_Click;
            // 
            // employee_grid
            // 
            employee_grid.Anchor = AnchorStyles.None;
            employee_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            employee_grid.Location = new Point(3, 508);
            employee_grid.Name = "employee_grid";
            employee_grid.RowHeadersWidth = 51;
            employee_grid.Size = new Size(1433, 372);
            employee_grid.TabIndex = 5;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.Image = Properties.Resources.business_people;
            pictureBox1.Location = new Point(12, 115);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(313, 219);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // employee
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1621, 945);
            Controls.Add(pictureBox1);
            Controls.Add(employee_grid);
            Controls.Add(DataDialerVoip);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "employee";
            Text = "employee";
            Load += employee_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)employee_grid).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private Label DataDialerVoip;
        private DataGridView employee_grid;
        private PictureBox pictureBox1;
    }
}