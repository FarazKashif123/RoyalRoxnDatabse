﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace Royal_Roxn.Db
{
    public partial class Dashboard : Form
    {


        public Dashboard()
        {
            InitializeComponent();






        }
        public void loadform(object form)
        {
            if (this.panel.Controls.Count > 0)
                this.panel.Controls.RemoveAt(0);
            Form f = form
                as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.panel.Controls.Add(f);
            this.panel.Tag = f;
            f.Show();






        }


        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            loadform(new about());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            loadform(new management_info());
        }

        private void dept_button_Click(object sender, EventArgs e)
        {
            loadform(new Departments());



        }

        private void button4_Click(object sender, EventArgs e)
        {
            loadform(new Realtor_s_Info());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            loadform(new employee());
        }

        private void panel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
