﻿namespace Royal_Roxn.Db
{
    partial class Realtor_s_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Realtor_s_Info));
            label1 = new Label();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            r_gridview = new DataGridView();
            DataDialerVoip = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)r_gridview).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(3, 19);
            label1.Name = "label1";
            label1.Size = new Size(132, 34);
            label1.TabIndex = 0;
            label1.Text = "Realtors";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(51, 102, 153);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1643, 53);
            panel1.TabIndex = 4;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.aaa;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(12, 99);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(189, 158);
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // r_gridview
            // 
            r_gridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            r_gridview.Location = new Point(0, 333);
            r_gridview.Name = "r_gridview";
            r_gridview.RowHeadersWidth = 51;
            r_gridview.Size = new Size(1121, 365);
            r_gridview.TabIndex = 6;
            // 
            // DataDialerVoip
            // 
            DataDialerVoip.Anchor = AnchorStyles.None;
            DataDialerVoip.AutoSize = true;
            DataDialerVoip.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            DataDialerVoip.Location = new Point(240, 76);
            DataDialerVoip.Name = "DataDialerVoip";
            DataDialerVoip.Size = new Size(962, 154);
            DataDialerVoip.TabIndex = 7;
            DataDialerVoip.Text = resources.GetString("DataDialerVoip.Text");
            // 
            // Realtor_s_Info
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1643, 724);
            Controls.Add(DataDialerVoip);
            Controls.Add(r_gridview);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Realtor_s_Info";
            Text = "Realtor's_Info";
            Load += Realtor_s_Info_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)r_gridview).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private PictureBox pictureBox1;
        private DataGridView r_gridview;
        private Label DataDialerVoip;
    }
}