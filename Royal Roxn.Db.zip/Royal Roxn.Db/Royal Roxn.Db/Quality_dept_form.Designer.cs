﻿namespace Royal_Roxn.Db
{
    partial class Quality_dept_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            qc_gridview = new DataGridView();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            DataDialerVoip = new Label();
            ((System.ComponentModel.ISupportInitialize)qc_gridview).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // qc_gridview
            // 
            qc_gridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            qc_gridview.Location = new Point(726, 79);
            qc_gridview.Name = "qc_gridview";
            qc_gridview.RowHeadersWidth = 51;
            qc_gridview.Size = new Size(1155, 585);
            qc_gridview.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Image = Properties.Resources.assurance;
            pictureBox1.Location = new Point(70, 181);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(333, 219);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(128, 64, 0);
            panel1.Controls.Add(DataDialerVoip);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1924, 52);
            panel1.TabIndex = 0;
            // 
            // DataDialerVoip
            // 
            DataDialerVoip.AutoSize = true;
            DataDialerVoip.Font = new Font("Tahoma", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DataDialerVoip.Location = new Point(0, 16);
            DataDialerVoip.Name = "DataDialerVoip";
            DataDialerVoip.Size = new Size(285, 36);
            DataDialerVoip.TabIndex = 2;
            DataDialerVoip.Text = "Quality Assurance";
            // 
            // Quality_dept_form
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.dd;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1924, 667);
            Controls.Add(pictureBox1);
            Controls.Add(qc_gridview);
            Controls.Add(panel1);
            Name = "Quality_dept_form";
            Text = "Quality_dept_form";
            Load += Quality_dept_form_Load;
            ((System.ComponentModel.ISupportInitialize)qc_gridview).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private DataGridView qc_gridview;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Label DataDialerVoip;
    }
}