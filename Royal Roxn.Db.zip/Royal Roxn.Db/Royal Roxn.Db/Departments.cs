﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Royal_Roxn.Db
{
    public partial class Departments : Form
    {
        public Departments()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Departments_Load(object sender, EventArgs e)
        {

        }

        private void Acc_btn_Click(object sender, EventArgs e)
        {
            Accounts acc = new Accounts();
            acc.Show();
        }



        private void button3_Click(object sender, EventArgs e)
        {

            DDv_form data = new DDv_form();

            data.Show();
        }



        private void button2_Click_1(object sender, EventArgs e)
        {
            Quality_dept_form qualityForm = new Quality_dept_form();
            qualityForm.Show();
        }



        private void button5_Click(object sender, EventArgs e)
        {
            Marketing qq = new Marketing();
            qq.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ColdCalling cc = new ColdCalling();
            cc.Show();
        }
    }
}