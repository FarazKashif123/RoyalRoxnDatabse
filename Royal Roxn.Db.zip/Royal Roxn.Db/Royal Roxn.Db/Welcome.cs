namespace Royal_Roxn.Db
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SetStyle(ControlStyles.SupportsTransparentBackColor, true);

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                string username = textBox1.Text;
                string password = textBox2.Text;

                if (ValidateLogin(username, password))
                {
                    MessageBox.Show("Login successful!");
                    Dashboard dashboard = new Dashboard();
                    dashboard.Show();

                    this.Hide(); // Optionally hide the login form
                }
                else
                {
                    MessageBox.Show("Invalid username or password. Please try again.");
                }
            }
        }

        private static bool ValidateLogin(string username, string password)
        {
            // Here, you can add logic to validate against hardcoded credentials, a database, etc.
            // For example, hardcoded validation:
            return username == "admin" && password == "password123";
            

        }
    }
}
