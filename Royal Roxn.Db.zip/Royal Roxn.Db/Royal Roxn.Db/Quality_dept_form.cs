﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Royal_Roxn.Db
{
    public partial class Quality_dept_form : Form
    {
        public Quality_dept_form()
        {
            InitializeComponent();
        }

        private void Quality_dept_form_Load(object sender, EventArgs e)
        {

            string connstring = "server=localhost;uid=root;pwd=*#*#12345*#*#;database=royalroxntech";
            MySqlConnection con = new MySqlConnection();
            con.ConnectionString = connstring;
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from QualityAndValidation";

            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            qc_gridview.DataSource = dt;
            cmd.ExecuteNonQuery();
            con.Close();

        }
    }
}
