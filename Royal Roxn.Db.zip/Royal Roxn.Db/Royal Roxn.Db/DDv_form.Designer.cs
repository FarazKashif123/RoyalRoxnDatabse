﻿namespace Royal_Roxn.Db
{
    partial class DDv_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ddv_grid = new DataGridView();
            DataDialerVoip = new Label();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)ddv_grid).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // ddv_grid
            // 
            ddv_grid.BackgroundColor = SystemColors.ControlLight;
            ddv_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            ddv_grid.Location = new Point(1155, 156);
            ddv_grid.Name = "ddv_grid";
            ddv_grid.RowHeadersWidth = 51;
            ddv_grid.Size = new Size(698, 518);
            ddv_grid.TabIndex = 0;
            ddv_grid.CellContentClick += dataGridView1_CellContentClick;
            // 
            // DataDialerVoip
            // 
            DataDialerVoip.AutoSize = true;
            DataDialerVoip.Font = new Font("Tahoma", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DataDialerVoip.Location = new Point(0, 17);
            DataDialerVoip.Name = "DataDialerVoip";
            DataDialerVoip.Size = new Size(243, 36);
            DataDialerVoip.TabIndex = 1;
            DataDialerVoip.Text = "DataDialerVoip";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(102, 204, 255);
            panel1.Controls.Add(DataDialerVoip);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1853, 53);
            panel1.TabIndex = 2;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = Properties.Resources.system;
            pictureBox1.Location = new Point(65, 74);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(297, 248);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // DDv_form
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.qq;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1853, 674);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(ddv_grid);
            Name = "DDv_form";
            Text = "DDv_form";
            Load += DDv_form_Load;
            ((System.ComponentModel.ISupportInitialize)ddv_grid).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView ddv_grid;
        private Label DataDialerVoip;
        private Panel panel1;
        private PictureBox pictureBox1;
    }
}