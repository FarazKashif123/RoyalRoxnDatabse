﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Royal_Roxn.Db
{
    public partial class Department_Overview : Form
    {
        public Department_Overview()
        {
            InitializeComponent();
        }

        private void Department_Overview_Load(object sender, EventArgs e)
        {

        }
    }
}
