﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Royal_Roxn.Db
{
    public partial class ColdCalling : Form
    {
        public ColdCalling()
        {
            InitializeComponent();
        }

        private void ColdCalling_Load(object sender, EventArgs e)
        {
            string connstring = "server=localhost;uid=root;pwd=*#*#12345*#*#;database=royalroxntech";
            MySqlConnection con = new MySqlConnection();
            con.ConnectionString = connstring;
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from ColdCalling";

            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            cc_gridview.DataSource = dt;
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
