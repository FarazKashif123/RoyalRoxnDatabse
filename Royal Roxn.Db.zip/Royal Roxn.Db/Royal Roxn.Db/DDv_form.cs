﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Royal_Roxn.Db
{
    public partial class DDv_form : Form
    {
        public DDv_form()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DDv_form_Load(object sender, EventArgs e)
        {

            string connstring = "server=localhost;uid=root;pwd=*#*#12345*#*#;database=royalroxntech";
            MySqlConnection con = new MySqlConnection();
            con.ConnectionString = connstring;
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from DataDialervoIp";

            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            ddv_grid.DataSource = dt;
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
