﻿namespace Royal_Roxn.Db
{
    partial class ColdCalling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            DataDialerVoip = new Label();
            pictureBox1 = new PictureBox();
            cc_gridview = new DataGridView();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)cc_gridview).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(51, 102, 153);
            panel1.Controls.Add(DataDialerVoip);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1837, 53);
            panel1.TabIndex = 3;
            // 
            // DataDialerVoip
            // 
            DataDialerVoip.Anchor = AnchorStyles.None;
            DataDialerVoip.AutoSize = true;
            DataDialerVoip.Font = new Font("Tahoma", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            DataDialerVoip.Location = new Point(0, 17);
            DataDialerVoip.Name = "DataDialerVoip";
            DataDialerVoip.Size = new Size(375, 36);
            DataDialerVoip.TabIndex = 2;
            DataDialerVoip.Text = "ColdCalling Department";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = Properties.Resources.calling;
            pictureBox1.Location = new Point(22, 155);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(297, 248);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // cc_gridview
            // 
            cc_gridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            cc_gridview.Location = new Point(590, 59);
            cc_gridview.Name = "cc_gridview";
            cc_gridview.RowHeadersWidth = 51;
            cc_gridview.Size = new Size(1247, 465);
            cc_gridview.TabIndex = 6;
            // 
            // ColdCalling
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1837, 636);
            Controls.Add(cc_gridview);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Name = "ColdCalling";
            Text = "ColdCalling";
            Load += ColdCalling_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)cc_gridview).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label DataDialerVoip;
        private PictureBox pictureBox1;
        private DataGridView cc_gridview;
    }
}