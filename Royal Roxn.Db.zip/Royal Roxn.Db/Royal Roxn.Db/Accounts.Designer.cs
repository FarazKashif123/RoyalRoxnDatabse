﻿namespace Royal_Roxn.Db
{
    partial class Accounts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label1 = new Label();
            acc_gridview = new DataGridView();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)acc_gridview).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(102, 102, 153);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(-2, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(1844, 43);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(3, 8);
            label1.Name = "label1";
            label1.Size = new Size(342, 36);
            label1.TabIndex = 3;
            label1.Text = "Accounts Department";
            // 
            // acc_gridview
            // 
            acc_gridview.BackgroundColor = Color.FromArgb(255, 255, 204);
            acc_gridview.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            acc_gridview.Location = new Point(988, 137);
            acc_gridview.Name = "acc_gridview";
            acc_gridview.RowHeadersWidth = 51;
            acc_gridview.Size = new Size(854, 530);
            acc_gridview.TabIndex = 1;
            acc_gridview.CellContentClick += acc_gridview_CellContentClick;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = Properties.Resources.fund;
            pictureBox1.Location = new Point(34, 65);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(392, 335);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // Accounts
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.ss;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1840, 618);
            Controls.Add(pictureBox1);
            Controls.Add(acc_gridview);
            Controls.Add(panel1);
            Name = "Accounts";
            StartPosition = FormStartPosition.Manual;
            Text = "Accounts";
            Load += Accounts_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)acc_gridview).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private DataGridView acc_gridview;
        private Label label1;
        private PictureBox pictureBox1;
    }
}