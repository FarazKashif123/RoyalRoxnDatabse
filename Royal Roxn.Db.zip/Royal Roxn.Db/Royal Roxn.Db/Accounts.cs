﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.MonthCalendar;

namespace Royal_Roxn.Db
{
    public partial class Accounts : Form
    {

        public Accounts()
        {
            InitializeComponent();
        }
        public Accounts(Departments departments)
        {
            InitializeComponent();
        }

        private void Accounts_Load(object sender, EventArgs e)
        {
            string connstring = "server=localhost;uid=root;pwd=*#*#12345*#*#;database=royalroxntech";
            MySqlConnection con = new MySqlConnection();
            con.ConnectionString = connstring;
            con.Open();
            MySqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from Account";

            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            acc_gridview.DataSource = dt;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void account_Id_TextChanged(object sender, EventArgs e)
        {

        }

        private void name_TextChanged(object sender, EventArgs e)
        {

        }

        private void acc_gridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
